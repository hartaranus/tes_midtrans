from django.shortcuts import render

import uuid
from midtrans import Client,SANDBOX,gateway
from midtrans.request import SnapChargeReq

# Create your views here.
#Client Getter
def get_client():
	client = Client(
		client_key='SB-Mid-client-L9lytYVvyGYQReSU',
		server_key='SB-Mid-server-Bq4jaXeJu1RhpeYeGRgdtkPk',
		environment_tyoe=SANDBOX
		)
	print(client)
	return client

#Pembayaran sederhana
def bayar(request):
	#Buka payment gateway dengan Instantiate snap object
	snap = gateway.Snap(client=get_client())

	#Buat tagihan
	tagihan = SnapChargeReq(
		order_id = str(uuid.uuid4()),
		gross_amount = 50000
		)
		
	#Get token pembayaran berdasarkan tagihan
	token = snap.get_token(tagihan).token
	print('token : {}'.format(token))

	#Render function requirement
	template = 'index.html'
	context = {'token' : token}
	return render(request,template,context)


